import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Item } from './item.model';

@Injectable()
export class ItemService {
  constructor(
    @InjectModel(Item)
    private itemModel: typeof Item,
  ) {}

  async findAll(): Promise<Item[]> {
    return this.itemModel.findAll();
  }

  async findOne(id: number): Promise<Item | null> {
    return this.itemModel.findByPk(id);
  }

  async create(data: any): Promise<Item | null> {
    return this.itemModel.create(data);
  }

  async update(id: number, data: any): Promise<Item | null> {
    const item = await this.itemModel.findByPk(id);
    if (!item) return null;
    return item.update(data);
  }

  async remove(id: number): Promise<void> {
    const item = await this.itemModel.findByPk(id);
    if (item) await item.destroy();
  }
}
