import {
  Table,
  Column,
  Model,
  DataType,
  ForeignKey,
  BelongsTo,
  PrimaryKey,
  AutoIncrement,
} from 'sequelize-typescript';
import { Category } from 'src/categories/category.model';
import { SubCategory } from 'src/subCategories/subCategory.model';

@Table({ tableName: 'items', timestamps: false })
export class Item extends Model<Item> {
  @PrimaryKey
  @AutoIncrement
  @Column(DataType.INTEGER)
  declare id: number;

  @Column({ type: DataType.STRING, allowNull: false })
  name: string;

  @Column({ type: DataType.FLOAT, allowNull: false })
  price: number;

  @ForeignKey(() => Category)
  @Column(DataType.INTEGER)
  categoryId: number;

  @BelongsTo(() => Category)
  category: Category;

  @ForeignKey(() => SubCategory)
  @Column(DataType.INTEGER)
  subCategoryId: number;

  @BelongsTo(() => SubCategory)
  subCategory: SubCategory;
}
