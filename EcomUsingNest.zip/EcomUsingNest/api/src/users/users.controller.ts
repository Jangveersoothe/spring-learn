import { Controller, Get, Post, Body, Query } from '@nestjs/common';
import { PaginatedUsers, UsersService } from './users.service';
import { SafeUser } from './users.service';
import { CreateUserDto } from '../common/dto/create-user.dto';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  findAll(
    @Query('page') page = 1,
    @Query('limit') limit = 10,
  ): Promise<PaginatedUsers> {
    return this.usersService.findAll(+page, +limit);
  }

  @Post()
  create(@Body() createUserDto: CreateUserDto): Promise<SafeUser> {
    return this.usersService.create(createUserDto);
  }
}
