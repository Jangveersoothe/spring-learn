import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { User } from './user.model';
import { CreateUserDto } from 'src/common/dto/create-user.dto';

export interface SafeUser {
  id: number;
  phone: string;
  role: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface PaginatedUsers {
  users: SafeUser[];
  total: number;
  page: number;
  limit: number;
}

@Injectable()
export class UsersService {
  constructor(
    @InjectModel(User)
    private userModel: typeof User,
  ) {}

  async findAll(page: number, limit: number): Promise<PaginatedUsers> {
    const offset = (page - 1) * limit;
    const { count, rows } = await this.userModel.findAndCountAll({
      offset,
      limit,
    });

    const users: SafeUser[] = rows.map((user) => ({
      id: user.id,
      phone: user.phone,
      role: user.role,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    }));

    return {
      users,
      total: count,
      page,
      limit,
    };
  }

  async create(dto: CreateUserDto): Promise<SafeUser> {
    const newUser = await this.userModel.create(dto as any);

    const { id, phone, role, createdAt, updatedAt } = newUser;
    return { id, phone, role, createdAt, updatedAt };
  }
}
