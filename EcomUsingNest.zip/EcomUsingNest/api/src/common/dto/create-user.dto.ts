import { IsEnum, IsNotEmpty, IsPhoneNumber } from 'class-validator';

export enum UserRole {
  USER = 'user',
  ADMIN = 'admin',
}

export class CreateUserDto {
  @IsPhoneNumber('IN')
  phone: string;

  @IsEnum(UserRole)
  @IsNotEmpty()
  role: UserRole;
}
