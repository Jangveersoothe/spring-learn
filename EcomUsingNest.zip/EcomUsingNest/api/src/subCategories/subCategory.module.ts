import { Module } from '@nestjs/common';
import { SequelizeModule } from '@nestjs/sequelize';
import { SubCategory } from './subCategory.model';
import { SubCategoryService } from './subCategory.service';
import { SubCategoryController } from './subCategory.controller';

@Module({
  imports: [SequelizeModule.forFeature([SubCategory])],
  providers: [SubCategoryService],
  controllers: [SubCategoryController],
})
export class SubCategoryModule {}
