import {
  Controller,
  Get,
  Post,
  Param,
  Body,
  Query,
  Put,
  Delete,
} from '@nestjs/common';
import { SubCategoryService } from './subCategory.service';
import { SubCategory } from './subCategory.model';

@Controller('subCategories')
export class SubCategoryController {
  constructor(private readonly subCategoryService: SubCategoryService) {}

  @Get()
  findAll(@Query('categoryId') categoryId?: string): Promise<SubCategory[]> {
    return this.subCategoryService.findAll(
      categoryId ? +categoryId : undefined,
    );
  }

  @Get(':id')
  findOne(@Param('id') id: string): Promise<SubCategory | null> {
    return this.subCategoryService.findOne(+id);
  }

  @Post()
  create(
    @Body('name') name: string,
    @Body('categoryId') categoryId: number,
  ): Promise<SubCategory> {
    return this.subCategoryService.create(name, categoryId);
  }

  @Put()
  update(
    @Param('id') id: string,
    @Body('name') name: string,
  ): Promise<SubCategory | null> {
    return this.subCategoryService.update(+id, name);
  }

  @Delete(':id')
  remove(@Param('id') id: string): Promise<void> {
    return this.subCategoryService.remove(+id);
  }
}
