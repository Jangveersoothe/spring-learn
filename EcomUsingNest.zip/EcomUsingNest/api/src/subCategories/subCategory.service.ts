import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { SubCategory } from './subCategory.model';

@Injectable()
export class SubCategoryService {
  constructor(
    @InjectModel(SubCategory)
    private subCategoryModel: typeof SubCategory,
  ) {}

  async findAll(categoryId?: number): Promise<SubCategory[]> {
    const where = categoryId ? { categoryId } : undefined;
    return this.subCategoryModel.findAll({ where });
  }

  async findOne(id: number): Promise<SubCategory | null> {
    return this.subCategoryModel.findByPk(id);
  }

  async create(name: string, categoryId: number): Promise<SubCategory> {
    return this.subCategoryModel.create({ name, categoryId } as SubCategory);
  }

  async update(id: number, name: string): Promise<SubCategory | null> {
    const subCategory = await this.subCategoryModel.findByPk(id);
    if (!subCategory) return null;
    subCategory.name = name;
    return subCategory.save();
  }

  async remove(id: number): Promise<void> {
    const subCategory = await this.subCategoryModel.findByPk(id);
    if (subCategory) await subCategory.destroy();
  }
}
