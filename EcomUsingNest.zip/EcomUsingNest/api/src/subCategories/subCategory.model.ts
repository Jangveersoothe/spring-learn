import {
  Table,
  Column,
  Model,
  DataType,
  ForeignKey,
  BelongsTo,
  HasMany,
  PrimaryKey,
  AutoIncrement,
} from 'sequelize-typescript';
import { Category } from 'src/categories/category.model';
import { Item } from '../items/item.model';

@Table({ tableName: 'subCategories', timestamps: false })
export class SubCategory extends Model<SubCategory> {
  @PrimaryKey
  @AutoIncrement
  @Column(DataType.INTEGER)
  declare id: number;

  @Column({ type: DataType.STRING, allowNull: false })
  name: string;

  @ForeignKey(() => Category)
  @Column(DataType.INTEGER)
  categoryId: number;

  @BelongsTo(() => Category)
  category: Category;

  @HasMany(() => Item)
  item: Item[];
}
