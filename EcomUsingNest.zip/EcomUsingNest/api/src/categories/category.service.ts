import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Category } from './category.model';

@Injectable()
export class CategoryService {
  constructor(
    @InjectModel(Category)
    private categoryModel: typeof Category,
  ) {}

  async findAll(): Promise<Category[]> {
    return this.categoryModel.findAll();
  }

  async findOne(id: number): Promise<Category | null> {
    return this.categoryModel.findByPk(id);
  }

  async create(name: string): Promise<Category> {
    return this.categoryModel.create({ name } as Category);
  }

  async update(id: number, name: string): Promise<Category | null> {
    const category = await this.categoryModel.findByPk(id);
    if (!category) return null;
    category.name = name;
    return category.save();
  }

  async remove(id: number): Promise<void> {
    const category = await this.categoryModel.findByPk(id);
    if (category) await category.destroy();
  }
}
