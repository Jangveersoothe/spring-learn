import {
  Table,
  Column,
  Model,
  DataType,
  HasMany,
  PrimaryKey,
  AutoIncrement,
} from 'sequelize-typescript';
import { SubCategory } from '../subCategories/subCategory.model';
import { Item } from '../items/item.model';

@Table({ tableName: 'categories', timestamps: false })
export class Category extends Model<Category> {
  @PrimaryKey
  @AutoIncrement
  @Column(DataType.INTEGER)
  declare id: number;

  @Column({ type: DataType.STRING, allowNull: false })
  name: string;

  @HasMany(() => SubCategory)
  subCategories: SubCategory[];

  @HasMany(() => Item)
  items: Item[];
}
